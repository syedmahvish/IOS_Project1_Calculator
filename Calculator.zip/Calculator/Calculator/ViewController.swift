//
//  ViewController.swift
//  Calculator
//
//  Created by Mahvish Syed on 25/04/21.
//  Copyright © 2021 Mahvish Syed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    enum OperationEnum{
        case add
        case sub
        case div
        case mul
    }
    

    @IBOutlet weak var resultTextfield: UITextField!
    
    var prevNumber : Double?
    var operation : OperationEnum?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultTextfield.keyboardType = .numberPad
    }
    
    @IBAction func numberButton(_ sender: Any) {
        if let numB = sender as? UIButton,
            let num = numB.tag as? Int,
            let numString = String(num) as? String {
            resultTextfield.text?.append(numString)
        }
    }
    
    @IBAction func clear(_ sender: Any) {
        resultTextfield.text = ""
        prevNumber = 0.0
    }
   

    @IBAction func add(_ sender: Any) {
        operation = OperationEnum.add
        if let num = resultTextfield.text{
             prevNumber =  Double(num)
             resultTextfield.text = ""
        }
       
    }
    
    @IBAction func sub(_ sender: Any) {
        operation = OperationEnum.sub
        if let num = resultTextfield.text{
            prevNumber =  Double(num)
            resultTextfield.text = ""
        }
    }
    
    
    @IBAction func mul(_ sender: Any) {
        operation = OperationEnum.mul
        if let num = resultTextfield.text{
            prevNumber =  Double(num)
            resultTextfield.text = ""
        }
    }
    
    @IBAction func div(_ sender: Any) {
        operation = OperationEnum.div
        if let num = resultTextfield.text{
            prevNumber =  Double(num)
            resultTextfield.text = ""
        }
    }
    
    
    @IBAction func result(_ sender: Any) {
        var result = 0.0
        
        guard let currNum = resultTextfield.text
            else{ return }
        switch operation! {
        case .add:
            guard let fnum = prevNumber, let snum = Double(currNum)
                else { return}
           result = fnum + snum
            
        case .sub:
            guard let fnum = prevNumber, let snum = Double(currNum)
                else { return}
            result = fnum - snum
            
        case .mul:
            guard let fnum = prevNumber, let snum = Double(currNum)
                else { return}
            result = fnum * snum
            
        case .div:
            guard let fnum = prevNumber, let snum = Double(currNum), snum != 0.0
                else { return}
            result = fnum / snum
            
        default:
            break
        }
        
        prevNumber = 0.0
        resultTextfield.text = String(result)
    }
    
    
    
}

